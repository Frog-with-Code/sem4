// Лабораторная работа №1 по дисциплине ЛОИС
// Выполнена студентом группы 421702 БГУИР Шумилов Артем Андреевич
// Главный файл программы.
// 15.03.2026;
//
// Ссылки на источники
/* Standard Template Library (STL) in C++ [Электронный ресурс]
 * GeeksForGeeks. – Режим доступа: https://www.geeksforgeeks.org/cpp/the-c-standard-template-library-stl/.
 * – Дата доступа: 20.04.2026.
 */

#include <iostream>
#include <string>
#include <map>
#include "validators/pcnf_validator.hpp"
#include <settings.hpp>

void runTests()
{
    int passed = 0;
    int failed = 0;

    for (const auto &[formula, expected] : TEST_CASES)
    {
        PcnfValidator validator(formula);
        ValidationResult result = validator.validate();

        if (result.code == expected)
        {
            std::cout << "[OK]   \"" << formula << "\"\n";
            ++passed;
        }
        else
        {
            std::cout << "[FAIL] \"" << formula << "\""
                      << " — ожидался код " << expected
                      << ", получен " << result.code;
            if (!result.message.empty())
            {
                std::cout << " (" << result.message << ")";
            }
            std::cout << "\n";
            ++failed;
        }
    }

    std::cout << "\nРезультат: " << passed << " пройдено, "
              << failed << " провалено\n";
}

void checkFormula()
{
    std::string formula;
    std::cout << "Введите формулу: ";
    std::getline(std::cin, formula);

    PcnfValidator validator(formula);
    ValidationResult result = validator.validate();

    if (result.code == 0)
    {
        std::cout << "Формула является СКНФ\n";
    }
    else
    {
        if (!result.message.empty())
        {
            std::cout << result.message << "\n";
        }
        std::cout << "Формула НЕ является СКНФ (код ошибки: " << result.code << ")\n";
    }
}

int main()
{
    while (true)
    {
        std::cout << "\n1 — ввести формулу\n"
                     "2 — запустить тесты\n"
                     "3 — синтаксис языка\n"
                     "0 — выход\n"
                     "> ";

        std::string choice;
        std::getline(std::cin, choice);

        if (choice == "1")
            checkFormula();
        else if (choice == "2")
            runTests();
        else if (choice == "3")
        {
            std::cout << "(A/\\B) - конъюнкция\n";
            std::cout << "(A\\/B) - дизъюнкция\n";
            std::cout << "(A->B) - импликация\n";
            std::cout << "(A~B) - эквиваленция\n";
            std::cout << "(!A) - отрицание\n";
            std::cout << "1 - истина\n";
            std::cout << "0 - ложь\n";

            std::cout << "\n"
                      << R"(СКНФ может содержать только /\, \/, !)" << "\n";
        }
        else if (choice == "0")
            break;
        else
            std::cout << "Неизвестная команда\n";
    }

    return 0;
}