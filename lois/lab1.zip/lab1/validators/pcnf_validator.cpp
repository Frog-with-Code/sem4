// Лабораторная работа №1 по дисциплине ЛОИС
// Выполнена студентом группы 421702 БГУИР Шумилов Артем Андреевич
// Файл реализации класса PcnfValidator.
// 15.03.2026;
//
// Ссылки на источники
/* Microsoft Learn: стандартная библиотека C++ utility [Электронный ресурс]
 * Microsoft Learn. – Режим доступа: https://learn.microsoft.com/ru-ru/cpp/standard-library/utility?view=msvc-170.
 * – Дата доступа: 29.03.2026.
 */

/* Abstract Syntax Tree (AST) [Электронный ресурс]
 * DEV Community. – Режим доступа:  https://dev.to/balapriya/abstract-syntax-tree-ast-explained-in-plain-english-1h38.
 * – Дата доступа: 04.04.2026.
 */

/* Google AI Studio [Электронный ресурс]
 * Google AI Studio. – Режим доступа:  https://aistudio.google.com/.
 * – Дата доступа: 07.04.2026.
 */

#include <iostream>
#include "pcnf_validator.hpp"
#include "../settings.hpp"

PcnfValidator::PcnfValidator(const std::string &formula)
    : FormulaValidator(formula)
{
}

ValidationResult PcnfValidator::validate() const
{
    ValidationResult baseResult = FormulaValidator::validate();
    if (baseResult.code != 0)
        return baseResult;

    return validatePCNF();
}

enum class NodeType
{
    Variable,
    Negation,
    Disjunction,
    Conjunction,
    Implication,
    Equivalence
};

struct ASTNode
{
    NodeType type;
    char var = '\0';
    ASTNode *left = nullptr;
    ASTNode *right = nullptr;

    ~ASTNode()
    {
        delete left;
        delete right;
    }
};

ASTNode *parseFormula(std::string_view s, int &errorCode, std::string &errorMsg)
{
    if (s.empty())
    {
        errorCode = 2;
        errorMsg = "Ошибка: пустая подформула";
        return nullptr;
    }

    if (s.size() == 1)
    {
        char c = s[0];
        if (c >= startAlphabet && c <= endAlphabet)
        {
            return new ASTNode{NodeType::Variable, c};
        }
        errorCode = 2;
        errorMsg = "Ошибка: недопустимый символ в качестве переменной: '" + std::string(1, c) + "'";
        return nullptr;
    }

    if (s.front() == OPEN_BRACKET && s.back() == CLOSE_BRACKET)
    {
        std::string_view inner = s.substr(1, s.size() - 2);

        if (inner.size() >= DENIAL.size() && inner.substr(0, DENIAL.size()) == DENIAL)
        {
            std::string_view sub = inner.substr(DENIAL.size());
            ASTNode *child = parseFormula(sub, errorCode, errorMsg);
            if (!child)
                return nullptr;
            return new ASTNode{NodeType::Negation, '\0', child};
        }

        int balance = 0;
        std::vector<size_t> opIndices;
        std::vector<NodeType> opTypes;
        std::vector<size_t> opSizes;

        for (size_t i = 0; i < inner.size(); ++i)
        {
            if (inner[i] == OPEN_BRACKET)
            {
                ++balance;
            }
            else if (inner[i] == CLOSE_BRACKET)
            {
                --balance;
                if (balance < 0)
                {
                    errorCode = 2;
                    errorMsg = "Ошибка: нарушение баланса скобок";
                    return nullptr;
                }
            }
            else if (balance == 0)
            {
                if (i + CONJUNCTION.size() <= inner.size() && inner.substr(i, CONJUNCTION.size()) == CONJUNCTION)
                {
                    opIndices.push_back(i);
                    opTypes.push_back(NodeType::Conjunction);
                    opSizes.push_back(CONJUNCTION.size());
                }
                else if (i + DISJUNCTION.size() <= inner.size() && inner.substr(i, DISJUNCTION.size()) == DISJUNCTION)
                {
                    opIndices.push_back(i);
                    opTypes.push_back(NodeType::Disjunction);
                    opSizes.push_back(DISJUNCTION.size());
                }
                else if (i + IMPLICATION.size() <= inner.size() && inner.substr(i, IMPLICATION.size()) == IMPLICATION)
                {
                    opIndices.push_back(i);
                    opTypes.push_back(NodeType::Implication);
                    opSizes.push_back(IMPLICATION.size());
                }
                else if (i + EQUALS.size() <= inner.size() && inner.substr(i, EQUALS.size()) == EQUALS)
                {
                    opIndices.push_back(i);
                    opTypes.push_back(NodeType::Equivalence);
                    opSizes.push_back(EQUALS.size());
                }
            }
        }

        if (opIndices.empty())
        {
            errorCode = 2;
            errorMsg = "Ошибка: не найден бинарный оператор в \"" + std::string(s) + "\"";
            return nullptr;
        }

        if (opIndices.size() > 1)
        {
            errorCode = 2;
            errorMsg = "Ошибка: лишние скобки или плоская запись бинарных операций в \"" + std::string(s) + "\"";
            return nullptr;
        }

        size_t opIdx = opIndices[0];
        NodeType opType = opTypes[0];
        size_t opSize = opSizes[0];

        std::string_view leftStr = inner.substr(0, opIdx);
        std::string_view rightStr = inner.substr(opIdx + opSize);

        ASTNode *leftNode = parseFormula(leftStr, errorCode, errorMsg);
        if (!leftNode)
            return nullptr;

        ASTNode *rightNode = parseFormula(rightStr, errorCode, errorMsg);
        if (!rightNode)
        {
            delete leftNode;
            return nullptr;
        }

        return new ASTNode{opType, '\0', leftNode, rightNode};
    }

    errorCode = 2;
    errorMsg = "Ошибка: формула не обёрнута в скобки: \"" + std::string(s) + "\"";
    return nullptr;
}

void collectVars(const ASTNode *node, std::set<char> &vars)
{
    if (!node)
        return;
    if (node->type == NodeType::Variable)
    {
        vars.insert(node->var);
    }
    collectVars(node->left, vars);
    collectVars(node->right, vars);
}

void collectClauses(const ASTNode *node, std::vector<const ASTNode *> &clauses)
{
    if (!node)
        return;
    if (node->type == NodeType::Conjunction)
    {
        collectClauses(node->left, clauses);
        collectClauses(node->right, clauses);
    }
    else
    {
        clauses.push_back(node);
    }
}

bool collectLiterals(const ASTNode *node, std::vector<std::string> &literals, int &errorCode, std::string &errorMsg)
{
    if (!node)
        return true;
    if (node->type == NodeType::Conjunction)
    {
        errorCode = 4;
        errorMsg = "Ошибка: конъюнкция внутри дизъюнкта";
        return false;
    }
    if (node->type == NodeType::Disjunction)
    {
        return collectLiterals(node->left, literals, errorCode, errorMsg) &&
               collectLiterals(node->right, literals, errorCode, errorMsg);
    }
    if (node->type == NodeType::Variable)
    {
        literals.push_back(std::string(1, node->var));
        return true;
    }
    if (node->type == NodeType::Negation)
    {
        if (node->left && node->left->type == NodeType::Variable)
        {
            literals.push_back("(!" + std::string(1, node->left->var) + ")");
            return true;
        }
        else
        {
            errorCode = 4;
            errorMsg = "Ошибка: отрицание применяется не к переменной";
            return false;
        }
    }
    errorCode = 4;
    errorMsg = "Ошибка: недопустимая операция в дизъюнкте";
    return false;
}
ASTNode *parseFormula(std::string_view s, int &errorCode, std::string &errorMsg)
{
    if (s.empty())
    {
        errorCode = 2;
        errorMsg = "Ошибка: пустая подформула";
        return nullptr;
    }

    if (s.size() == 1)
    {
        char c = s[0];
        if (c >= startAlphabet && c <= endAlphabet)
        {
            return new ASTNode{NodeType::Variable, c};
        }
        errorCode = 2;
        errorMsg = "Ошибка: недопустимый символ в качестве переменной: '" + std::string(1, c) + "'";
        return nullptr;
    }

    if (s.front() == OPEN_BRACKET && s.back() == CLOSE_BRACKET)
    {
        std::string_view inner = s.substr(1, s.size() - 2);

        if (inner.size() >= DENIAL.size() && inner.substr(0, DENIAL.size()) == DENIAL)
        {
            std::string_view sub = inner.substr(DENIAL.size());
            ASTNode *child = parseFormula(sub, errorCode, errorMsg);
            if (!child)
                return nullptr;
            return new ASTNode{NodeType::Negation, '\0', child};
        }

        int balance = 0;
        std::vector<size_t> opIndices;
        std::vector<NodeType> opTypes;
        std::vector<size_t> opSizes;

        for (size_t i = 0; i < inner.size(); ++i)
        {
            if (inner[i] == OPEN_BRACKET)
            {
                ++balance;
            }
            else if (inner[i] == CLOSE_BRACKET)
            {
                --balance;
                if (balance < 0)
                {
                    errorCode = 2;
                    errorMsg = "Ошибка: нарушение баланса скобок";
                    return nullptr;
                }
            }
            else if (balance == 0)
            {
                if (i + CONJUNCTION.size() <= inner.size() && inner.substr(i, CONJUNCTION.size()) == CONJUNCTION)
                {
                    opIndices.push_back(i);
                    opTypes.push_back(NodeType::Conjunction);
                    opSizes.push_back(CONJUNCTION.size());
                }
                else if (i + DISJUNCTION.size() <= inner.size() && inner.substr(i, DISJUNCTION.size()) == DISJUNCTION)
                {
                    opIndices.push_back(i);
                    opTypes.push_back(NodeType::Disjunction);
                    opSizes.push_back(DISJUNCTION.size());
                }
                else if (i + IMPLICATION.size() <= inner.size() && inner.substr(i, IMPLICATION.size()) == IMPLICATION)
                {
                    opIndices.push_back(i);
                    opTypes.push_back(NodeType::Implication);
                    opSizes.push_back(IMPLICATION.size());
                }
                else if (i + EQUALS.size() <= inner.size() && inner.substr(i, EQUALS.size()) == EQUALS)
                {
                    opIndices.push_back(i);
                    opTypes.push_back(NodeType::Equivalence);
                    opSizes.push_back(EQUALS.size());
                }
            }
        }

        if (opIndices.empty())
        {
            errorCode = 2;
            errorMsg = "Ошибка: не найден бинарный оператор в \"" + std::string(s) + "\"";
            return nullptr;
        }

        if (opIndices.size() > 1)
        {
            errorCode = 2;
            errorMsg = "Ошибка: лишние скобки или плоская запись бинарных операций в \"" + std::string(s) + "\"";
            return nullptr;
        }

        size_t opIdx = opIndices[0];
        NodeType opType = opTypes[0];
        size_t opSize = opSizes[0];

        std::string_view leftStr = inner.substr(0, opIdx);
        std::string_view rightStr = inner.substr(opIdx + opSize);

        ASTNode *leftNode = parseFormula(leftStr, errorCode, errorMsg);
        if (!leftNode)
            return nullptr;

        ASTNode *rightNode = parseFormula(rightStr, errorCode, errorMsg);
        if (!rightNode)
        {
            delete leftNode;
            return nullptr;
        }

        return new ASTNode{opType, '\0', leftNode, rightNode};
    }

    errorCode = 2;
    errorMsg = "Ошибка: формула не обёрнута в скобки: \"" + std::string(s) + "\"";
    return nullptr;
}
char variableOfLiteral(std::string_view lit)
{
    if (lit.size() == 1)
        return lit[0];
    return lit[1 + DENIAL.size()];
}

ValidationResult PcnfValidator::validatePCNF() const
{
    int errorCode = 0;
    std::string errorMsg;
    ASTNode *root = parseFormula(formula_, errorCode, errorMsg);
    if (!root)
    {
        return {errorCode, errorMsg};
    }

    std::set<char> vars;
    collectVars(root, vars);
    if (vars.empty())
    {
        delete root;
        return {5, "Ошибка: формула не содержит переменных"};
    }

    bool isSingleLiteral = (root->type == NodeType::Variable) ||
                           (root->type == NodeType::Negation && root->left && root->left->type == NodeType::Variable);
    if (isSingleLiteral)
    {
        delete root;
        return {0, ""};
    }

    std::vector<const ASTNode *> clauses;
    collectClauses(root, clauses);

    if (clauses.size() < 2)
    {
        delete root;
        return {1, "Ошибка: неверное количество дизъюнктов"};
    }

    std::set<std::set<std::string>> uniqueClauses;
    for (const auto *clause : clauses)
    {
        std::vector<std::string> lits;
        if (!collectLiterals(clause, lits, errorCode, errorMsg))
        {
            delete root;
            return {errorCode, errorMsg};
        }

        std::set<char> seen;
        for (const auto &lit : lits)
        {
            char v = variableOfLiteral(lit);
            if (!seen.insert(v).second)
            {
                delete root;
                return {3, "Ошибка: переменная '" + std::string(1, v) + "' встречается в дизъюнкте более одного раза"};
            }
        }

        if (seen != vars)
        {
            delete root;
            return {3, "Ошибка: дизъюнкт содержит не все переменные формулы"};
        }

        std::set<std::string> litSet(lits.begin(), lits.end());
        if (!uniqueClauses.insert(litSet).second)
        {
            delete root;
            return {1, "Ошибка: дизъюнкт встречается более одного раза"};
        }
    }

    delete root;
    return {0, ""};
}