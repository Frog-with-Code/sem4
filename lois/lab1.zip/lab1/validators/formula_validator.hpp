// Лабораторная работа №1 по дисциплине ЛОИС
// Выполнена студентом группы 421702 БГУИР Шумилов Артем Андреевич
// Заголовочный файл базового класса FormulaValidator.
// 17.03.2026;

#ifndef FORMULA_VALIDATOR_HPP
#define FORMULA_VALIDATOR_HPP

#include <string>
#include "ivalidator.hpp"

class FormulaValidator : public IValidator
{
public:
    explicit FormulaValidator(const std::string &formula);

    ValidationResult validate() const override;

protected:
    std::string formula_;

private:
    bool containsVariables() const;
    bool hasBalancedBrackets(std::string &err_msg) const;
    bool hasValidSymbols(std::string &err_msg) const;
};

#endif