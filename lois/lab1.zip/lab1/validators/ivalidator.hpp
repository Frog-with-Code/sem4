// Лабораторная работа №1 по дисциплине ЛОИС
// Выполнена студентом группы 421702 БГУИР Шумилов Артем Андреевич
// Заголовочный файл абстрактного класса IValidator.
// 15.03.2026;
//
// Ссылки на источники
/* C++ - Pure Virtual Functions and Abstract Classes [Электронный ресурс]
 * TutorialsPoint. – Режим доступа: https://www.tutorialspoint.com/cplusplus/cpp_pure_virtual_functions_vs_abstract_classes.html.
 * – Дата доступа: 29.03.2026.
 */


#ifndef IVALIDATOR_HPP
#define IVALIDATOR_HPP

#include <string>

struct ValidationResult
{
    int code;
    std::string message;
};

class IValidator
{
public:
    virtual ~IValidator() = default;

    // Возвращает код и текст ошибки:
    //   0 — формула является СКНФ
    //   1 — неверное количество дизъюнктов или дублирование
    //   2 — некорректные скобки или недопустимые символы
    //   3 — дизъюнкт содержит не все переменные формулы или содержит дубликат
    //   4 — элемент дизъюнкта не является литералом
    //   5 — формула не содержит переменных
    virtual ValidationResult validate() const = 0;
};

#endif