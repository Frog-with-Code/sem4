// Лабораторная работа №1 по дисциплине ЛОИС
// Выполнена студентом группы 421702 БГУИР Шумилов Артем Андреевич
// Заголовочный файл класса PcnfValidator.
// 15.03.2026;

// Ссылки на источники
/* Standard Template Library (STL) in C++ [Электронный ресурс]
 * GeeksForGeeks. – Режим доступа: https://www.geeksforgeeks.org/cpp/the-c-standard-template-library-stl/.
 * – Дата доступа: 20.04.2026.
 */

/* Microsoft Learn: стандартная библиотека C++ utility [Электронный ресурс]
 * Microsoft Learn. – Режим доступа: https://learn.microsoft.com/ru-ru/cpp/standard-library/utility?view=msvc-170.
 * – Дата доступа: 22.04.2026.
 */

#ifndef PCNF_VALIDATOR_HPP
#define PCNF_VALIDATOR_HPP

#include <string>
#include <string_view>
#include <set>
#include <vector>
#include "formula_validator.hpp"

class PcnfValidator : public FormulaValidator
{
public:
    explicit PcnfValidator(const std::string &formula);

    ValidationResult validate() const override;

private:
    ValidationResult validatePCNF() const;
};

#endif