// Лабораторная работа №1 по дисциплине ЛОИС
// Выполнена студентом группы 421702 БГУИР Шумилов Артем Андреевич
// Файл реализации базового класса FormulaValidator.
// 17.03.2026;
//
// Ссылки на источники
/* Standard Template Library (STL) in C++ [Электронный ресурс]
 * GeeksForGeeks. – Режим доступа: https://www.geeksforgeeks.org/cpp/the-c-standard-template-library-stl/.
 * – Дата доступа: 20.04.2026.
 */

#include <vector>
#include <algorithm>
#include "formula_validator.hpp"
#include "../settings.hpp"

FormulaValidator::FormulaValidator(const std::string &formula)
    : formula_(formula)
{
}

bool FormulaValidator::hasValidSymbols(std::string &err_msg) const
{
    size_t i = 0;
    while (i < formula_.size())
    {
        const char c = formula_[i];

        if (c == OPEN_BRACKET || c == CLOSE_BRACKET)
        {
            ++i;
            continue;
        }

        if (c >= startAlphabet && c <= endAlphabet)
        {
            ++i;
            continue;
        }

        if (formula_.compare(i, DENIAL.size(), DENIAL) == 0)
        {
            i += DENIAL.size();
            continue;
        }

        if (formula_.compare(i, CONJUNCTION.size(), CONJUNCTION) == 0)
        {
            i += CONJUNCTION.size();
            continue;
        }

        if (formula_.compare(i, DISJUNCTION.size(), DISJUNCTION) == 0)
        {
            i += DISJUNCTION.size();
            continue;
        }

        if (formula_.compare(i, IMPLICATION.size(), IMPLICATION) == 0)
        {
            i += IMPLICATION.size();
            continue;
        }

        if (formula_.compare(i, EQUALS.size(), EQUALS) == 0)
        {
            i += EQUALS.size();
            continue;
        }

        err_msg = "Ошибка: недопустимый символ на позиции " + std::to_string(i + 1) + ": '" + c + "'";
        return false;
    }
    return true;
}

bool FormulaValidator::containsVariables() const
{
    for (const auto &c : formula_)
    {
        if (c >= startAlphabet && c <= endAlphabet)
            return true;
    }
    return false;
}

bool FormulaValidator::hasBalancedBrackets(std::string &err_msg) const
{
    int balance = 0;
    for (const auto &c : formula_)
    {
        if (c == OPEN_BRACKET)
            ++balance;
        else if (c == CLOSE_BRACKET)
        {
            --balance;
            if (balance < 0)
            {
                err_msg = "Ошибка: лишняя закрывающая скобка";
                return false;
            }
        }
    }
    if (balance != 0)
    {
        err_msg = "Ошибка: незакрытые скобки (" + std::to_string(balance) + " шт.)";
        return false;
    }
    return true;
}

ValidationResult FormulaValidator::validate() const
{
    std::string err_msg;

    if (!hasValidSymbols(err_msg))
    {
        return {2, err_msg};
    }
    if (!containsVariables())
    {
        return {5, "Ошибка: формула не содержит переменных"};
    }
    if (!hasBalancedBrackets(err_msg))
    {
        return {2, err_msg};
    }
    return {0, ""};
}